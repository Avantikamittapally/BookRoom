import Featured from "../../components/featured/Featured";
import FeaturedProperties from "../../components/featuredProperties/FeaturedProperties";
import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";
import MailList from "../../components/mailList/MailList";
import Navbar from "../../components/navbar/Navbar";
import PropertyList from "../../components/propertyList/PropertyList";
import { useNavigate } from "react-router-dom";


const Home = () => {
    const navigate = useNavigate()
    const handleClick = () => {
   
        navigate("/success")
        
      };
  return (
    <div>
      <Navbar />
      <Header/>
      <div className="homeContainer">
      <button onClick={handleClick}>Confirm to Book Now!</button>
      </div>
    </div>
  );
};

export default Home;
